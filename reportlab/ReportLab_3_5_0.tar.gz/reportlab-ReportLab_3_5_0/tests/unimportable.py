#module you cannot import
"""
This is a fixture used for testing a dynamic import function.

It is supposed to produce an error when imported.
"""

value = 100 / 0


